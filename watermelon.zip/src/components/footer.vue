<template>
	<div class="w-footer">
		<el-row :gutter="10">
			版权所有:西瓜先生    粤ICP备18024062号-1
		</el-row>
	</div>
</template>
<style>
	.w-footer{
		text-align: center;
		padding: 9px 0 12px;
		color: #99a9bf;
		background-color: #fbfbfb;
	}
</style>