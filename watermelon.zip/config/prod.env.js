'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_URL: '"http://www.panzhihui.cn/watermelon"',
  BASE_API: '"http://www.panzhihui.cn/watermelon_api/"',
  PACK_NAME:'"/watermelon/"',
}
